export type ShipStatus =
  | 'normal'
  | 'rerouting'
  | 'distressed'
  | 'stopped'
  | 'stranded'
  | 'insufficient_fuel'
  | 'arrived'
  | 'out_of_fuel'

export interface Position {
  lat: number
  lng: number
}

export interface Port {
  id: string
  name: string
  position: [number, number]  // [lat, lng]
}

export interface Ship {
  id: string
  name: string
  lat: number
  lng: number
  speed: number           // knots
  heading: number         // degrees 0-360
  destination: {
    portId: string
    name: string
    lat: number
    lng: number
  }
  fuel: number            // tons remaining
  maxFuel: number         // tons at start (for percentage display)
  cargo: string
  status: ShipStatus
  inAdverseWeather: boolean
  route: Position[]
  lastUpdated: number
}

export type AlertType =
  | 'GEOFENCE_BREACH'
  | 'PROXIMITY_WARNING'
  | 'STRANDED'
  | 'INSUFFICIENT_FUEL'
  | 'OUT_OF_FUEL'

export type Severity = 'low' | 'medium' | 'high' | 'critical'

export interface Zone {
  id: string
  coordinates: [number, number][]
  label: string
  createdAt: number
}

export interface Alert {
  id: string
  type: AlertType
  severity: Severity
  shipId: string
  message: string
  active: boolean
  acknowledged: boolean
  createdAt: number
}

export interface Directive {
  id: string
  shipId: string
  fromCommand: true
  type: 'CHANGE_DESTINATION' | 'HOLD_POSITION' | 'REROUTE_WAYPOINT'
  payload: {
    destination?: { lat: number; lng: number; name: string }
    waypoint?: { lat: number; lng: number }
  }
  sentAt: number
}

export interface DistressParseResult {
  shipId: string
  raw: string
  severity: Severity
  issueType: string
  injuries: number
  damageEstimate: 'none' | 'minor' | 'moderate' | 'major' | 'total_loss'
  impact: string
  recommendedAction: string
  parsedAt: number
}

export interface Snapshot {
  timestamp: number
  ships: Ship[]
}

export interface FleetScenario {
  scenario: { name: string; description: string }
  coordinateFormat: string
  units: { speed: string; fuel: string; heading: string }
  boundingBox: { north: number; south: number; east: number; west: number }
  navigableWater: [number, number][]
  ports: Array<{ id: string; name: string; position: [number, number] }>
  fleet: Array<{
    shipId: string
    name: string
    position: [number, number]
    speed: number
    heading: number
    destination: string
    fuel: number
    cargo: string
    status: string
  }>
}
