import { Ship } from '@/lib/types'
import { ShipStatusBadge } from './ShipStatusBadge'

export function ShipDetailCard({ ship, title = 'Selected Vessel' }: { ship?: Ship; title?: string }) {
  if (!ship) {
    return (
      <section className="panel glass-subtle">
        <div className="panelTitleRow">
          <h2 style={{ fontSize: '12px', fontWeight: 600, letterSpacing: '0.15em', color: 'rgba(148,163,184,0.45)' }}>
            {title.toUpperCase()}
          </h2>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 120, gap: 12 }}>
          <div style={{ fontSize: '32px', opacity: 0.3 }}>◇</div>
          <p className="muted" style={{ fontSize: '13px' }}>Select a vessel marker<br />to inspect live ship state</p>
        </div>
      </section>
    )
  }

  const fuelPercent = Math.round((ship.fuel / ship.maxFuel) * 100)

  return (
    <section className="panel glass-subtle">
      <div className="panelTitleRow" style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <h3 style={{ fontSize: '14px', fontWeight: 700, color: '#e8f7ff', margin: 0 }}>
            {ship.name}
          </h3>
          <span style={{ fontSize: '11px', color: 'rgba(148,163,184,0.5)', fontFamily: 'monospace' }}>
            {ship.id}
          </span>
        </div>
        <ShipStatusBadge status={ship.status} />
      </div>

      <div className="metricGrid" style={{ gap: '8px' }}>
        {[
          { label: 'CARGO', value: ship.cargo },
          { label: 'FUEL', value: `${ship.fuel.toFixed(0)}t`, tone: fuelPercent < 15 ? 'warn' : fuelPercent > 50 ? 'good' : undefined },
          { label: 'FUEL %', value: `${fuelPercent}%`, tone: fuelPercent < 15 ? 'warn' : fuelPercent > 50 ? 'good' : undefined },
          { label: 'SPEED', value: `${ship.speed} kt` },
          { label: 'HEADING', value: `${Math.round(ship.heading)}°` },
          { label: 'DESTINATION', value: ship.destination.name },
          { label: 'WEATHER', value: ship.inAdverseWeather ? '⚠ ADVERSE' : '✓ CLEAR', tone: ship.inAdverseWeather ? 'warn' : 'good' },
          { label: 'UPDATED', value: new Date(ship.lastUpdated).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) },
        ].map((metric, i) => (
          <div key={i} className="metric" style={{ background: 'rgba(2,6,23,0.45)', padding: '10px', borderRadius: '6px' }}>
            <span style={{ fontSize: '10px', letterSpacing: '0.1em', color: 'rgba(148,163,184,0.5)' }}>
              {metric.label}
            </span>
            <strong style={{
              fontSize: '13px',
              color: metric.tone === 'warn' ? '#ffb800' : metric.tone === 'good' ? '#00ff88' : '#e8f7ff',
              fontFamily: 'monospace',
            }}>
              {metric.value}
            </strong>
          </div>
        ))}
      </div>

      {/* Route preview */}
      {ship.route && ship.route.length > 1 && (
        <div style={{ marginTop: 16, padding: 12, background: 'rgba(2,6,23,0.4)', borderRadius: '8px', border: '1px solid rgba(0,212,255,0.1)' }}>
          <div style={{ fontSize: '10px', fontWeight: 600, letterSpacing: '0.15em', color: 'rgba(148,163,184,0.5)', marginBottom: 8 }}>
            ROUTE PREVIEW
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: '11px', color: 'rgba(148,163,184,0.7)', marginBottom: 6 }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#00d4ff" strokeWidth="2">
              <path d="M12 2L6 20L12 16L18 20L12 2Z"/>
            </svg>
            <span style={{ fontFamily: 'monospace', color: '#00d4ff' }}>POS: {ship.lat.toFixed(3)}°N, {ship.lng.toFixed(3)}°E</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: '11px', color: 'rgba(148,163,184,0.7)' }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#ffb800" strokeWidth="2">
              <circle cx="12" cy="12" r="4"/>
            </svg>
            <span style={{ fontFamily: 'monospace', color: '#ffb800' }}>DEST: {ship.destination.name} ({ship.destination.lat.toFixed(2)}, {ship.destination.lng.toFixed(2)})</span>
          </div>
          <div style={{ marginTop: 8, display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            {ship.route.slice(0, 3).map((wp, idx) => (
              <span key={idx} style={{
                padding: '2px 6px',
                background: 'rgba(0,212,255,0.1)',
                border: '1px solid rgba(0,212,255,0.2)',
                borderRadius: '4px',
                fontSize: '9px',
                fontFamily: 'monospace',
                color: 'rgba(148,163,184,0.8)',
              }}>
                WP{idx + 1}: {wp.lat.toFixed(1)}, {wp.lng.toFixed(1)}
              </span>
            ))}
            {ship.route.length > 3 && (
              <span style={{ padding: '2px 6px', fontSize: '9px', color: 'rgba(148,163,184,0.5)' }}>
                +{ship.route.length - 3} more
              </span>
            )}
          </div>
        </div>
      )}
    </section>
  )
}
